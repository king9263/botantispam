#!/bin/bash

while true; do
	lua bot.lua
	sleep 5s
done
